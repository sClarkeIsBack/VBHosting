import base64

addon_name   = base64.b64decode('VkIgSG9zdGluZw==')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLnZiaG9zdGluZw==')

host         = base64.b64decode('aHR0cDovL3d3dy52Ymhvc3RpbmcuY28udWs=')
port         = base64.b64decode('MjU0NjE=')