import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnZiaG9zdGluZ3R2')

name = b.b64decode('VkIgSG9zdGluZyBUVg==')

host = b.b64decode('aHR0cDovL3ZvZGJveGlwdHYuZGRucy5uZXQ=')

port = b.b64decode('MjU0NjE=')